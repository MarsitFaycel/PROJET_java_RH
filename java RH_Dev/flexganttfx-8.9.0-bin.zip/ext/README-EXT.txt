This directory contains third-party jar files:

- controlsfx-xxx.jar

  Custom controls developed as part of the open source project ControlsFX.
  
- license4j-1.4.0.jar

  Support for licensing keys.
  
  
  